The factoring project was originally written in VS 2013. I have worked on it in VS 2015.

I mainly refactored the code in 1 CS file only; it is "Order.cs". Please see the updated codes in that file. I include my comments in that file.

